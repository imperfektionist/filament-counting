function bin = HistogramCurve(EL, binWidth)

% Make and plot histograms
% h = histogram(EL, 'BinWidth', binWidth);
% bin.centers = h.BinEdges(1:end-1) - binWidth / 2;
% bin.counts = h.Values / sum(EL);

[counts, edges] = histcounts(EL, 'BinWidth', binWidth);
bin.centers = edges(1:end-1) - binWidth / 2;
bin.counts = counts / sum(EL);