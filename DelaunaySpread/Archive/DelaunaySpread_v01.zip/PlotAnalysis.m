% Plot filament XY positions
if do.plotXY
    screen_size = get(0, 'ScreenSize');
    fig = figure('Position', [0 0 screen_size(3) screen_size(4)]);
    plot(xy_true(:,1), xy_true(:,2), 'k.')
    hold on
    plot(xy_synth(:,1), xy_synth(:,2), 'r.')
    axis equal
    legend('True','Synth')
    title("Filament Positions")
end

% Plot true delaunay triangulation
if do.plotDelaunayTrue
    figure('Position', [0 0 screen_size(3) screen_size(4)]);
    triplot(DT_true, xy_true(:,1), xy_true(:,2), 'k');
    axis equal
    title("Delaunay Triangulation (True)")
end

% Plot synthetic delaunay triangulation
if do.plotDelaunaySynth
    figure('Position', [0 0 screen_size(3) screen_size(4)]);
    triplot(DT_synth, xy_synth(:,1), xy_synth(:,2), 'r');
    axis equal
    title("Delaunay Triangulation (Synth)")
end

% Calculate and display histogram data
if do.plotHistogram
    hist_true = HistogramCurve(EL_true, binWidth);
    hist_synth = HistogramCurve(EL_synth, binWidth);
    
    figure;
    plot(hist_true.centers, hist_true.counts, 'k')
    hold on
    plot(hist_synth.centers, hist_synth.counts, 'r')
    legend('True','Synth')
    title("Neighbor Distance Histogram")
    xlabel('Edge Length')
    ylabel('Relative Occurrence')
end