function [xy_synth, DT_synth, EL_synth] = IterateSpread(xy_synth, EL_true, num_iters)

m = median(EL_true);

% No iterations
if num_iters == 0
    [DT_synth, EL_synth] = DelaunayTriangulation(xy_synth, [0, 10]);
end

% Iterative algorithm with decreasing step width 1/i
for iter = 1:num_iters

    fprintf("Iteration: %d/%d\n", iter, num_iters)

    [DT_synth, EL_synth] = DelaunayTriangulation(xy_synth, [0, 10]);

    % Get neighbors of each point
    N = size(xy_synth, 1);
    neighbors = cell(N, 1);
    for d = 1:size(DT_synth, 1)        
        edges = nchoosek(DT_synth(d,:),2);
        for j = 1:3
            pt1 = edges(j, 1);
            pt2 = edges(j, 2);
            neighbors{pt1}(end+1) = pt2;
            neighbors{pt2}(end+1) = pt1;
        end
    end

    % Move each point towards equal spacing
    xy_next = xy_synth;
    for p = 1:N
        neighs = unique(neighbors{p});  % remove duplicates

        for n = 1:length(neighs)
            a = xy_synth(p,:);  % absolute center vector
            b = xy_synth(neighs(n),:);  % absolute neighbor vector
            c = b - a;  % relative vector
            d = norm(c);  % relative vector magnitude
            %s = c / d * (d - m)^2 * sign(d - m);  % shift vector
            s = c * (1 - m / d);  % shift vector
            xy_next(p,:) = xy_next(p,:) + s / iter;  % absolute shift
        end
    end
    xy_synth = xy_next;
    
end